#ifndef BMPPROCESSOR_H
#define BMPPROCESSOR_H

#include "PixelProcessor.h"

#include <stdio.h>

struct BMP_Header {
	char signature[2];			//ID Field
	int size;								//size of the BMP file
	short reserved1;    		//application-specific
	short reserved2;    		//application-specific
	int offset_pixel_array; //starting address of the pixel array
};

struct DIB_Header{
	int size;						 			 //size of this header
	int width; 				 				 //image width
	int height; 			 				 //image height
	short planes; 			 			 //the number of color planes
	short bits_per_pixel; 		 //the number of bits per pixel (color depth of the image)
	int compression; 					 //the compression method being used
	int image_size;					 	 //the size of this image (size of raw bitmap data)
	int x_pixels_per_meter; 	 //horizontal resolution of the image in pixels-per-meter
	int y_pixels_per_meter;    //vertical resolution of the image in pixels-per-meter
	int color_palette_size; 	 //number of colors in the color palette. 0 to 2^n
	int important_color_count; //number of important colors used. 0 when all colors are important
};

/**
 * read BMP header of a file. Useful for converting files from PPM to BMP.
 *
 * @param  file: A pointer to the file being read or written
 * @param  header: Pointer to the destination BMP header
 */
void readBMPHeader(FILE* file, struct BMP_Header* header);

/**
 * write BMP header of a file. Useful for converting files from PPM to BMP.
 *
 * @param  file: A pointer to the file being read or written
 * @param  header: The header made by makeBMPHeader function
 */
void writeBMPHeader(FILE* file, struct BMP_Header* header);

/**
 * read DIB header from a file. Useful for converting files from PPM to BMP.
 *
 * @param  file: A pointer to the file being read or written
 * @param  header: Pointer to the destination DIB header
 */
void readDIBHeader(FILE* file, struct DIB_Header* header);

/**
 * write DIB header of a file. Useful for converting files from PPM to BMP.
 *
 * @param  file: A pointer to the file being read or written
 * @param  header: The header made by makeDIBHeader function
 */
void writeDIBHeader(FILE* file, struct DIB_Header* header);

/**
 * make BMP header based on width and height.
 * The purpose of this is to create a new BMPHeader struct using the information
 * from a PPMHeader when converting from PPM to BMP.
 *
 * @param  header: Pointer to the destination DIB header
 * @param  width: Width of the image that this header is for
 * @param  height: Height of the image that this header is for
 */
void makeBMPHeader(struct BMP_Header* header, int width, int height);


 /**
 * Makes new DIB header based on width and height. Useful for converting files from PPM to BMP.
 *
 * @param  header: Pointer to the destination DIB header
 * @param  width: Width of the image that this header is for
 * @param  height: Height of the image that this header is for
 */
void makeDIBHeader(struct DIB_Header* header, int width, int height);


/**
 * read Pixels from BMP file based on width and height.
 *
 * @param  file: A pointer to the file being read or written
 * @param  pArr: Pixel array of the image that this header is for
 * @param  width: Width of the image that this header is for
 * @param  height: Height of the image that this header is for
 */
void readPixelsBMP(FILE* file, struct Pixel** pArr, int width, int height);


/**
 * write Pixels from BMP file based on width and height.
 *
 * @param  file: A pointer to the file being read or written
 * @param  pArr: Pixel array of the image that this header is for
 * @param  width: Width of the image that this header is for
 * @param  height: Height of the image that this header is for
 */
void writePixelsBMP(FILE* file, struct Pixel** pArr, int width, int height);

#endif
